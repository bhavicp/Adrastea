/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.jme3.audio;

/**
 *
 * @author Nehon
 */
public interface SeekableStream{
    
    public void setTime(float time);
    
}
