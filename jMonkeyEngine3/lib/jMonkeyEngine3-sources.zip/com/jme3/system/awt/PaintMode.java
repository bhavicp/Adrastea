package com.jme3.system.awt;

public enum PaintMode {
    Accelerated,
    Repaint,
    OnRequest;
}
